import { Component } from '@angular/core';

@Component({
  selector: 'app-pagamentos',
  templateUrl: 'pagamentos.page.html',
  styleUrls: ['pagamentos.page.scss']
})
export class PagamentosPage {}
