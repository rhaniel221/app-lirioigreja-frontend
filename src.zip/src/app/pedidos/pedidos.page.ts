import { Component } from '@angular/core';

@Component({
  selector: 'app-pedidos',
  templateUrl: 'pedidos.page.html',
  styleUrls: ['pedidos.page.scss']
})
export class PedidosPage {}
